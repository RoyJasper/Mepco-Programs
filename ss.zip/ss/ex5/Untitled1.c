#include <stdio.h>
#include <stdlib.h>
main()
{
 int i,n;
 printf("ENter n");
 scanf("%d",&n);
 for(i=0;i<n;i++)
 printf("%x ,i");
 }
