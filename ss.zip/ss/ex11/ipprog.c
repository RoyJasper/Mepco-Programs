#include<stdio.h>
#include<stdlib.h>
#include<math.h>
main()
{
int a,b,c,i;
b=5;
a=b;
i=0;
c=a+b;
a=b*c+d-e;
}
