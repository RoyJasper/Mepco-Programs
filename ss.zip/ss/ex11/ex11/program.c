#include<stdio.h>
#include<stdlib.h>
main()
{
int a,b,c,d,e;
e=0;
a=5;
a=b;
while (e!=10)
{
	i=0;
	i=a+b;
}
a=b*c+d-e;
e=b/a+c+d;
}
