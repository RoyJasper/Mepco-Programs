# include <stdio.h>
int main ( )
{
 int b [ 20 ] ;
 int a = 30 + 40 ;
 printf ( " ans is % d  " , a );
}
