#include<stdio>#include<string>main(){int a,b;}
