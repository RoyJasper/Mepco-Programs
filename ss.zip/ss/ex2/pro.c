#include<stdio.h>
int main( )
{
 int a=30+40;
 printf("ans is % d",a);
}

