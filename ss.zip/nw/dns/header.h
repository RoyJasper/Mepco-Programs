
#include<stdio.h>

#include<stdlib.h>

#include<sys/types.h>

#include<netdb.h>

#include<errno.h>

#include<signal.h>

#include<unistd.h>

#include<arpa/inet.h>

#include<string.h>

#include<sys/wait.h>

#include<sys/socket.h>

#include<netinet/in.h>

#include<time.h>
